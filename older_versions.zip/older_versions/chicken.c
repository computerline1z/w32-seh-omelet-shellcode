/*
    Chicken: egg creator for Omlet Egghunt shellcode.

    Chicken takes one parameter: the size of the eggs, this cannot be greater
    then 255. Chicken reads shellcode from stdin and writes the eggs to stdout.
    See Omlet Egghunt code for details on the eggs.
*/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    int eggsize, input, i, j;
    char marker[4] = { 0x31, 0x33, 0x33, 0x37 };
    char buffer[0x100];

    if (argc!=2 || (eggsize = atoi(argv[1]))>0xFF || eggsize<1) {
        fprintf(stderr, "Usage: %s [EGG SIZE]\n", argv[0]);
        return EXIT_FAILURE;
    }
    do {
        for (i=0; i<eggsize; i++) {
            input = getchar();
            if (input == EOF) break;
            buffer[i] = (char) input;
        }
        printf("%c%c%c%c", marker[0], marker[1], marker[2], marker[3]);
        printf("%c", (char) (i-1));
        for (j=0; j<i; j++)
            printf("%c", buffer[j]);
    } while (i==eggsize);
    printf("%c%c%c%c\xFF", marker[0], marker[1], marker[2], marker[3]);
    return EXIT_SUCCESS;
}
